/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package josue_arceexamen;

/**
 *
 * @author arceb
 */
public class Talonario {
   
   private String Ticket [];
   private int nfilas = 10;
   private int ncol = 10;
    private int numero = 0 ;
    
   Talonario ticket[][]=new Talonario[10][10];

    
    
  
   
   
    
    
   
   
  
    
}





