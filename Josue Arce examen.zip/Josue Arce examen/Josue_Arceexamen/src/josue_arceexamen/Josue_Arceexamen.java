/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package josue_arceexamen;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author arceb
 */
public class Josue_Arceexamen {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    int aleatorio;
    int Ticket;
    int opciones;
    String  GalloTapado;    
   String Estadisticas;
   String adquirir;
   String datos;
   int Datos;
   
   
    do{
    opciones = Integer.parseInt(JOptionPane.showInputDialog("Menu de opciones"
    
     +"1. Adquirir numero especifico \n"       
     +"2. Gallo Tapado (Aleatorio) \n "
     +"3. Consultar su COmpra \n  "
     +"4.Estadistica y Recaudacion \n"
     +"5.Sorteo \n "
     +"6. Salida \n"
         
    
    ));
    
    switch (opciones) {
            case 1:
                addnum();
                break;
            case 2:
                galloTapado();
                break;
            case 3:
                JOptionPane.showMessageDialog( null, "Tus copras han sido");
                break;
            case 4:            
                 
                break;
            case 5:   
               
                break;
            case 6: 
                JOptionPane.showMessageDialog( null, "saliendo del prgrama.....");
                break;

}
    }while(opciones != 6 );

    private void addnum(){
    
    if(opciones==1){
        
     Ticket = Integer.parseInt(JOptionPane.showInputDialog("Elija el numero de ticket que desea comprar"));
      
    datos=JOptionPane.showInputDialog("Ingrese su nombre");
    Datos= Integer.parseInt(JOptionPane.showInputDialog("Diguite su numero de telefono"));
     
    } else {
    
    JOptionPane.showInternalMessageDialog(null,"Este numero ya no esta disponible");
    
    
    }
    }
    
    
    private void galloTapado(){
    
    if (opciones == 2){
    
    GalloTapado = JOptionPane.showInputDialog("Indique la cantidad de boletos que desea comprar");
       
    
    
    }
       
    if (opciones == 3){
    
    JOptionPane.showInternalMessageDialog(null,"el estado actual del talonario es"+Ticket);
    
  
    }
    
    
    
    
    
    
    
    
    
    
    
    
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    }
    
    
    
    
    
    
    
    
    
    

